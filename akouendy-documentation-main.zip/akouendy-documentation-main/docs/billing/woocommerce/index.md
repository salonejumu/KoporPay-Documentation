# Utiliser la passerelle de paiement Woocommerce d'Akouendy
!!! note ""
    Vous pouvez à tout moment dans la console Akouendy ou nous contacter à support@akouendy.com pour demander de l'aide pour vos configuration.

!!! note annotate "Etape 1: Installer le plugin Woocommerce Akouendy Gateway"
Rechercher le plugin dans votre site worpress et installez-le.

<figure markdown>
  ![Image title](/assets/plugin-wordpress.jpg){ width="850" }
  <figcaption>Recherche du plugin</figcaption>
</figure>

!!! note annotate "Etape 2: Configurer le plugin Woocommerce Akouendy Gateway"
Dans la liste des plugins, cliquez sur le lien réglages puis activez les moyens de paiement. 
<figure markdown>
  ![Image title](/assets/plugin-wordpress-enable.jpg){ width="850" }
  <figcaption>Activation du plugin</figcaption>
</figure>
Pour configurer le plugin, rendez-vous dans la console Akouendy, créez une application puis
renseignez la clé privée et le token. 

<figure markdown>
  ![Image title](/assets/plugin-wordpress-credentials.jpg){ width="850" }
  <figcaption>Configuration du plugin</figcaption>
</figure>
Utilisez, les paramètres de la même application pour configurez tous les moyens de paiements.

!!! note annotate "Etape 3: Créer une application dans Akouendy Billing"
Une application se créé dans le menu "Développeur" et fournit les paramètres (clé privée et token) pour configurer vos supports d'encaissement d'argent (site web, facture, ect). Pour avoir une meilleure statistique (paiemment , moyen de paiement, ect) par supports, il est recommandé de créer une application par support.
<figure markdown>
  ![Image title](/assets/create-application.jpg){ width="850" }
  <figcaption>Exemple de l'application Akouendy Shop</figcaption>
</figure>

!!! note annotate "Etape 4: Ajouter un produit et tester"
Pour valider votre configuration, ajoutez un produit de 5F puis testez.
Une fois les commandes passées, vous pouvez tous les paiements dans la console Akouendy.
<figure markdown>
  ![Image title](/assets/payment-dashboard.jpg){ width="850" }
  <figcaption>Liste des paiements dans la console Akouendy</figcaption>
</figure>
