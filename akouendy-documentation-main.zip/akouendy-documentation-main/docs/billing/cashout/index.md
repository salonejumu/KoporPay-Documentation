# Retrait d'argent
Les soldes des paiements encaissés sur la plateforme Akouendy sont automatiquement disponibles pour des retraits par Orange Money ou par Wave dans le menu "Retraits".
Les frais de retrait (1% par retrait) facturés par les opérateurs sont pris en charge par Akouendy. 
<figure markdown>
  ![Image title](/assets/cashout.jpg){ width="850" }
  <figcaption>Page des retraits</figcaption>
</figure>
Les paiements encaissés par Wave sont à retirer via un numéro Wave et ceux encaissé par Orange Money sont à retirer par Orange Money.
<figure markdown>
  ![Image title](/assets/cashout-sample.jpg){ width="500" }
  <figcaption>Exemple d'un retrait par Wave</figcaption>
</figure>
Lorsqu'un retrait est initié, un code OTP est envoyé au numéro de téléphone renseigné lors de l'[activation des paiements](/billing/getting-started/).
<figure markdown>
  ![Image title](/assets/cashout-otp.jpg){ width="500" }
  <figcaption>Formulaire de validation via OTP</figcaption>
</figure>
Veuillez contacter l'équipe Akouendy si vous ne recevez pas le message OTP ou si vous avez une erreur lors du retrait à support@akouendy.com.

