# Débuter avec la plateforme de paiment Akouendy
!!! note annotate "Etape 1: Créer un compte sur l'application Akouendy"

Pour commencer, vous devez créer un compte sur notre plateforme en vous rendant sur https://console.akouendy.com. Sur la page d'accueil, vous trouverez un lien ou un bouton pour vous inscrire. Cliquez dessus et suivez les instructions pour créer votre compte. Assurez-vous de fournir toutes les informations requises de manière précise.
<figure markdown>
  ![Image title](/assets/register.png){ width="500" }
  <figcaption>Création de compte</figcaption>
</figure>

!!! note annotate "Étape 2: Sélectionner le service Akouendy Billing"
Après la connexion dans la console d'Akouendy, tous les services disponibles s'affichent sur le dashboard.
Le service "Akouendy Billing" étant en bêta actuellement ne s'affichera pas si votre adhésion au programme de beta testeur n'est pas encore validé.
<figure markdown>
  ![Image title](/assets/services.png)
  <figcaption>Création de compte</figcaption>
</figure>


!!! note annotate "Étape 3: Activer les paiements"

Une fois que vous avez créé votre compte, Connectez-vous à la console d'Akouendy avec vos identifiants.
Selectionnez le service "Akouendy Billing". Cliquer sur le bouton "Activez les paiements" dans le menu "Configurations",  pour commencer à utiliser le service. 
<figure markdown>
  ![Image title](/assets/enable-payment.png)
  <figcaption>Activation des paiements</figcaption>
</figure>

Assurez-vous de fournir toutes les informations requises de manière précise. Le numéro mobile demandé sera utilisé pour valider les opérations de retrait d'argent. 

{==
Vous pouvez commencer à facturer vos clients sur vos différents supports dès validation de votre compte par l'équipe Akouendy.
==}

Si vous rencontrez des problèmes techniques ou si vous avez des questions supplémentaires, n'hésitez pas à contacter notre équipe d'assistance, qui se fera un plaisir de vous aider.
