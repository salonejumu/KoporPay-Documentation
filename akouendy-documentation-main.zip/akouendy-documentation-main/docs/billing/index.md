---
hide:
  - navigation
  - toc
---
# A propos du service Akouendy Billing[Beta]
Le service Akouendy Billing est conçu pour vous aider à gérer vos transactions avec aisance et efficacité. Que vous soyez un commerçant local ou une entreprise en pleine croissance, notre plateforme vous offre une solution pratique pour facturer vos clients via Orange Money et Wave.

<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } [__Activer les paiements__](/billing/getting-started/)

-   :material-cube-send:{ .lg .middle } [__Configurer Woocommerce__](/billing/woocommerce/)

</div>

# Fonctionnalités
- [x] Paiement par Orange Money et Wave Sénégal
- [x] Retrait instanné via Orange Money  et Wave Sénégal
- [x] Retrait instanné via Orange Money  et Wave Sénégal
- [ ] Intégration de notifications sms dans le plugin Woocommerce 
- [ ] Emission et envoi de facture par email ou sms
- [ ] Mise en place des statistiques et dashboards
- [ ] Environnement de tests

# Plugins
- [x] Gateway Woocommerce Wordpress
- [ ] SDK Golang (en cours)
- [ ] Librairie maven