---
hide:
  - navigation
  - toc
---
# A propos du service Akouendy Notifications
Akouendy offre une solution pratique et efficace pour l'envoi et la programmation de SMS en utilisant l'API SMS d'Orange. Avec notre plateforme conviviale et notre intégration transparente avec l'API d'Orange, vous pouvez facilement communiquer avec vos clients, vos partenaires ou vos utilisateurs de manière personnalisée et ciblée. Gagnez du temps précieux et maximisez l'impact de vos campagnes de marketing ou de communication en exploitant la puissance des SMS.

<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } [__Débuter en 5 min__](/notification/getting-started/)

-   :material-cube-send:{ .lg .middle } [__Configurer son compte Orange Developer__](#)

-   :material-send-clock:{ .lg .middle } [__Envoyer des sms__](#)

</div>


