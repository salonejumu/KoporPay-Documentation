La plateforme Akouendy offre une intégration transparente avec l'API d'Orange. Voici la documentation pour vous aider à démarrer avec notre service.

!!! note annotate "Pré-requis: Créer un compte sur l'application Akouendy"

Pour commencer, vous devez créer un compte sur notre plateforme en vous rendant sur https://console.akouendy.com. Sur la page d'accueil, vous trouverez un lien ou un bouton pour vous inscrire. Cliquez dessus et suivez les instructions pour créer votre compte. Assurez-vous de fournir toutes les informations requises de manière précise.

!!! note annotate "Étape 1: Souscrire à l'offre Akouendy Sénégal"

Une fois que vous avez créé votre compte, connectez-vous à l'application Akouendy avec vos identifiants. Naviguez jusqu'à la section "Offres" ou "Abonnements" et sélectionnez l'offre spécifique pour Akouendy Sénégal. Consultez les détails de l'offre, tels que les fonctionnalités incluses, les tarifs et les limites, puis suivez les instructions pour souscrire à l'offre.

Veuillez noter que vous devrez peut-être fournir certaines informations supplémentaires pour vérifier votre identité et respecter les réglementations locales.

!!! note annotate "Étape 2: Profiter des 5 messages gratuits pour les tests"

Après avoir terminé la souscription à l'offre Akouendy Sénégal, vous bénéficierez de 5 messages gratuits pour effectuer des tests. Ces messages vous permettront de vous familiariser avec notre service et de vérifier son bon fonctionnement.

Vous pouvez utiliser ces messages gratuits pour envoyer des SMS à des numéros de téléphone de votre choix. Assurez-vous de respecter les restrictions spécifiques à votre offre, telles que les limitations de volume ou les destinations autorisées.

Lors de l'envoi des SMS, assurez-vous de spécifier le numéro de téléphone de destination, le contenu du message et l'expéditeur (qui sera Akouendy). 

N'oubliez pas que l'utilisation du service SMS d'Akouendy est soumise aux conditions générales d'utilisation et aux réglementations locales. Assurez-vous de les lire attentivement et de respecter les politiques en vigueur.

Si vous rencontrez des problèmes techniques ou si vous avez des questions supplémentaires, n'hésitez pas à contacter notre équipe d'assistance, qui se fera un plaisir de vous aider.
