# akouendy-documentation
````
 python3 -m mkdocs serve
 ```